import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { CommonServiceService } from '../common-service.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [CommonServiceService]
})
export class HomeComponent implements OnInit {

   movieArray = [];
  constructor(private CommonServiceService: CommonServiceService) { }

  ngOnInit() {
    this.movieArray = this.CommonServiceService.getMovieList();
  }

}
