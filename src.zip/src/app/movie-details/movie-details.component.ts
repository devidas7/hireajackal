import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute,RouterModule, Routes } from '@angular/router';
import { CommonServiceService } from '../common-service.service';



@Component({
  selector: 'app-movie-details',
  templateUrl: './movie-details.component.html',
  styleUrls: ['./movie-details.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [CommonServiceService]
})
export class MovieDetailsComponent implements OnInit {
  currentMovie = {};
  constructor(private route:ActivatedRoute, private CommonServiceService: CommonServiceService) { }

  ngOnInit() {
    const id = +this.route.snapshot.paramMap.get('id');
    let movieList = this.CommonServiceService.getMovieList();
    this.currentMovie = movieList[id];
  }

}
