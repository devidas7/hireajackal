import { Injectable } from '@angular/core';

@Injectable()
export class CommonServiceService {

  constructor() { }

  getMovieList(){
    let data  = [
      {Name:'Kingsman the golden circle',category:['Adventure','comedy','Family'],desc:"Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati, accusantium mollitia! Deserunt ipsum impedit molestiae quisquam, facere ad doloremque ipsa nihil maxime nobis eligendi doloribus laudantium quaerat eum quos reru", rating:4.5,director:'Matthew Vaughn', commpany:'Marv Films', relese:'20 Sept 2017',MusicDirector:'Henry Jackman',banner:'kingsman-banner.jpg',thumb:'kingsman-thumbnail.jpg'},
      {Name:'woodshock',category:['Adventure','comedy','Family'],desc:"Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati, accusantium mollitia! Deserunt ipsum impedit molestiae quisquam, facere ad doloremque ipsa nihil maxime nobis eligendi doloribus laudantium quaerat eum quos reru", rating:4.0,director:'Matthew Vaughn', commpany:'Marv Films', relese:'20 Sept 2017',MusicDirector:'Henry Jackman',banner:'woodshock-banner.jpg',thumb:'woodshock-thumb.jpg'},
      {Name:'The LEGO Ninjago Movie',category:['Adventure','comedy','Family'],desc:"Lorem ipsum dolor sit amet consectetur, adipisicing elit. Obcaecati, accusantium mollitia! Deserunt ipsum impedit molestiae quisquam, facere ad doloremque ipsa nihil maxime nobis eligendi doloribus laudantium quaerat eum quos reru", rating:4.0,director:'Matthew Vaughn', commpany:'Marv Films', relese:'20 Sept 2017',MusicDirector:'Henry Jackman',banner:'the-lego.png',thumb:'lego-thumb.jpg'}
    ];

    return data;
  }

}
